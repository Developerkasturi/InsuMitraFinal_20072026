import{a as t}from"./addMonths-CrEQ1GQ8.js";function a(o,n){return t(o,-1)}export{a as s};
