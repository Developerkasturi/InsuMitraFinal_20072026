import { Module } from '@nestjs/common';
import { DeletionRequestsController } from './deletion-requests.controller';
import { DeletionRequestsService } from './deletion-requests.service';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [DeletionRequestsController],
  providers: [DeletionRequestsService],
  exports: [DeletionRequestsService],
})
export class DeletionRequestsModule {}
